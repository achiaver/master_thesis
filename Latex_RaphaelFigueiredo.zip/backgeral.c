void treinamento_do_backpropagation()
{
  for (e = 0; e < epocas; e++)
  {
    erro = 0.0;
    for ( p = 0 ; p < num_padroes ; p++ )
    {               
      for ( i = 0 ; i < num_camadas ; i++ )     /*   Para frente   */
      {
        for (j = 0 ; j < camada[i].num_neuronios ; j++ )
        {  
          camada[i].neuronio[j].h_in = 0.0;
          if (i == 0) 
          {
            camada[i].neuronio[j].V = ksi[p][j];
          }
          else  
          {
            for (k = 0 ; k < camada[i-1].num_neuronios + 1 ; k++ )
              camada[i].neuronio[j].h_in += (camada[i-1].neuronio[k].peso[j] * camada[i-1].neuronio[k].V); 
              camada[i].neuronio[j].V = tanh(beta * camada[i].neuronio[j].h_in);    
          }     
        }
        camada[i].neuronio[camada[i].num_neuronios].V = -threshold;         
      }       
      for ( i = num_camadas - 1; i > 0; i-- )      /*  Para tras  */    
      {
        for (j = 0 ; j < camada[i].num_neuronios ; j++ )
        {
        camada[i].neuronio[j].delta = 0.0;
         /*    Calculo do delta para ultima camada    */
          if (i == num_camadas -1)     
          {
            g_ativ = camada[i].neuronio[j].V;
            dg_ativ = beta * (1 - (g_ativ * g_ativ));
            camada[i].neuronio[j].delta =  dg_ativ * (desired_out[p][j] - camada[i].neuronio[j].V);
          }      
          else
          {
            sum = 0.0;
            /*    Calculo dos deltas das camadas intermediarias    */
            for (k = 0 ; k < camada[i+1].num_neuronios ; k++ )   
              sum += (camada[i].neuronio[j].peso[k] * camada[i+1].neuronio[k].delta);
              g_ativ = camada[i].neuronio[j].V;
              dg_ativ = beta * (1 - (g_ativ * g_ativ));
              camada[i].neuronio[j].delta = ( dg_ativ * sum );
          }  
        }    
      }  
       /*    Atualizacao dos pesos apos o calculo dos deltas    */
      for ( i = num_camadas - 1; i > 0; i-- )     
      {
        for (j = 0 ; j < camada[i].num_neuronios  ; j++ )
        {
          for (k = 0 ; k < camada[i-1].num_neuronios + 1 ; k++ )       
          { 
            delta_w = eta * (camada[i].neuronio[j].delta * camada[i-1].neuronio[k].V);
            camada[i-1].neuronio[k].peso[j] = camada[i-1].neuronio[k].peso[j] + momentum * delta_w;
          }
        }
      } 
        for (j = 0 ; j < camada[num_camadas-1].num_neuronios ; j++ )
          erro += 0.5 * ( (desired_out[p][j] - camada[num_camadas-1].neuronio[j].V) *
		  (desired_out[p][j] - camada[num_camadas-1].neuronio[j].V) );
    }   
    if (erro < error ) break;
  }
}

