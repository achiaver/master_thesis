#include <stdlib.h>
#include <stdio.h>
#include <math.h>	  
#include <string.h>	  
#include <malloc.h>	  

typedef struct NEURONIO_CONTENT{  

	double V;
	double V2;
	double *peso;
	double delta;
	double h_in;
	            
} neuronio_content;

typedef struct CAMADA_CONTENT{    

	int num_neuronios;
	struct NEURONIO_CONTENT *neuronio;
	                      
} camada_content;



